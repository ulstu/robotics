# -*- coding: utf- 8 -*-

from sys import argv

script, first, second, third = argv

print u"Этот сценарий называется:", script
print u"Моя первая переменная называется:", first
print u"Моя вторая переменная называется:", second
print u"Моя третья переменная называется:", third