# -*- coding: utf- 8 -*-

from sys import argv

script, input_file = argv

def print_all(f):
    print f.read()

def rewind(f):
    f.seek(0)

def print_a_line(line_count, f):
    print line_count, f.readline()

current_file = open(input_file)

print u"Первым делом выведем этот файл целиком:\n"

print_all(current_file)

print u"Теперь отмотаем назад, словно это кассета."

rewind(current_file)

print u"Выведем три строки:"

current_line = 1
print_a_line(current_line, current_file)

current_line = current_line + 1
print_a_line(current_line, current_file)

current_line = current_line + 1
print_a_line(current_line, current_file)
